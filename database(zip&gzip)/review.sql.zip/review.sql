-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 11, 2022 at 11:16 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `review`
--

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `SNo.` int(11) NOT NULL,
  `Name` text NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Message` text NOT NULL,
  `Date` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`SNo.`, `Name`, `Email`, `Message`, `Date`) VALUES(5, 'Demo_Aarya', 'aa2@gmail.com', 'second test', '2022-10-30 06:07:30');
INSERT INTO `contacts` (`SNo.`, `Name`, `Email`, `Message`, `Date`) VALUES(6, 'Rupali', 'rupali21comp@student.mes.ac.in', 'I love these songs.', '2022-11-03 09:44:15');
INSERT INTO `contacts` (`SNo.`, `Name`, `Email`, `Message`, `Date`) VALUES(7, 'khushnuma warsi', 'khushnuma21comp@student.mes.ac.in', 'These songs are my all time favourite.', '2022-11-03 09:45:57');
INSERT INTO `contacts` (`SNo.`, `Name`, `Email`, `Message`, `Date`) VALUES(8, 'Sneha Yadav', 'sneha240902@gmail.com', 'When more songs will be included?? By the way Website is designed very beautifully.\r\n', '2022-11-03 23:51:16');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `SNo` int(11) NOT NULL,
  `Title` text NOT NULL,
  `slug` varchar(25) NOT NULL,
  `Content` text NOT NULL,
  `Date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`SNo`, `Title`, `slug`, `Content`, `Date`) VALUES(1, 'First Post.', 'first-post', 'This is my First post. This is my First post. This is my First post. This is my First post. This is my First post.\r\n', '2022-11-02 10:05:47');

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `SNo` int(11) NOT NULL,
  `Title` text NOT NULL,
  `Content` text NOT NULL,
  `Name` text NOT NULL,
  `Date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`SNo`, `Title`, `Content`, `Name`, `Date`) VALUES(2, 'Aaj Din Chadeya ', 'There are few composition which are yours all-time favorite. It just drifts you to another world. I have bunch of my favorite and those are very close to my heart. Today, when I heard \"Ajj din Chadeya\" song from Love Aaj kal after long time, it made me feel the same way.', 'Aarya', '2022-11-03 09:12:43');
INSERT INTO `reviews` (`SNo`, `Title`, `Content`, `Name`, `Date`) VALUES(5, 'Night Changes', 'I do not think that this is a romantic song. If fact, I do not think that \"he\" plays a significant role in the story.  The young girl (daughter) want\'s it to happen but she wants it to be right and without regrets . The \"night\" is a metaphor for how quickly we all grow up. We all have hopes and dreams about how we want our lives.... and the lives of our loved ones...to play out. We all want to be the narrator of our life story. I\'m guessing that maybe the experience was not exactly what the young girl anticipated it to be.. or maybe it was but I do not think that\'s the point. ', 'Sneha', '2022-11-03 09:22:03');
INSERT INTO `reviews` (`SNo`, `Title`, `Content`, `Name`, `Date`) VALUES(8, 'Dildara', 'Nice sng fsghjhbdcngnrgvdmithjioythj gyyuftydeydfyuu', 'Khushnuma', '2022-11-04 03:43:38');
INSERT INTO `reviews` (`SNo`, `Title`, `Content`, `Name`, `Date`) VALUES(9, 'Dildara', 'Nice sng fsghjhbdcngnrgvdmithjioythj gyyuftydeydfyuu', 'Khushnuma', '2022-11-04 03:43:47');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`SNo.`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`SNo`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`SNo`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `SNo.` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `SNo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `SNo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
